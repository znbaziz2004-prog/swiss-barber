<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    public function handle(Request $request, Closure $next): Response
    {
        $supportedLanguages = ['en', 'de', 'fr', 'it', 'rm'];

        $locale = $request->session()->get('locale', 'en');

        if (!in_array($locale, $supportedLanguages, true)) {
            $locale = 'en';
        }

        App::setLocale($locale);

        return $next($request);
    }
}